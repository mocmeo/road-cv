﻿Pollux PowerPoint Template v1.0
Copyright(c): Jun Akizaki; 2016

1. Templateについて
商用、非商用にかかわらず、自由にお使いいただけます。
著作権は秋咲准が保有していますので、再配布したり、販売したりすることはできません。

2. お問い合わせ
ご質問などは
　http://thepopp.com/contactform
からお願いします。すべてのご質問にお答えできるかどうかわかりませんが、ご理解ください。
